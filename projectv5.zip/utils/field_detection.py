import cv2
import numpy as np

WEIGHT_OF_SCREEN = 1280
HEIGHT_OF_SCREEN = 720

# Field parameters
LeftUp = (233, 157)
LeftDown = (254, 572)
RightDown = (1082, 572)
RightUp = (1067, 162)
FieldContour = np.array([LeftUp, LeftDown, RightDown, RightUp])


# Net Detection
NTL = WEIGHT_OF_SCREEN * 0.35
NTR = WEIGHT_OF_SCREEN * 0.65

# Left line
LTL = WEIGHT_OF_SCREEN * 0.1
LTR = WEIGHT_OF_SCREEN * 0.25

# Right line
RTL = WEIGHT_OF_SCREEN * 0.75
RTR = WEIGHT_OF_SCREEN * 0.95

# Up line
UTT = HEIGHT_OF_SCREEN * 0.15
DTT = HEIGHT_OF_SCREEN * 0.35

# Bottom Line
UTB = HEIGHT_OF_SCREEN * 0.75
DTB = HEIGHT_OF_SCREEN * 0.95


class FieldDetection:

    UpLine = None
    LeftLine = None
    DownLine = None
    RightLine = None
    NetLine = None
    Gamma_Min = 52
    
    def init_frame(self, frame):
        # Gray
        current_frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Threshold
        res, binary = cv2.threshold(current_frame_gray, self.Gamma_Min, 255, cv2.THRESH_BINARY)
        # Canny algorithm
        edges = cv2.Canny(binary, 1, 255) 
        return edges

    def detect_lines(self, edges):
        # get the lines of te field
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, 7, np.array([]), 200, 100)
        if lines is not None:
            slopeLines = self.SlopeCalc(lines)
            self.NetLine = self.LinesFilter(slopeLines, NTL, NTR)
            self.UpLine = self.LinesFilter(slopeLines, UTT, DTT)
            self.LeftLine = self.LinesFilter(slopeLines, LTL, LTR)
            self.DownLine = self.LinesFilter(slopeLines, UTB, DTB)
            self.RightLine = self.LinesFilter(slopeLines, RTL, RTR)



    def detect_field(self, frame):
        LeftUp, LeftDown, RightDown, RightUp = 0, 0, 0, 0
        while(True):
            edges = self.init_frame(frame)
            self.detect_lines(edges)
            try:
                if self.UpLine is not None and self.LeftLine is not None:
                    # Left up corner
                   LeftUp = self.line_intersection(self.UpLine, self.LeftLine)

                if self.DownLine is not None and self.LeftLine is not None:
                    # Left down corner
                    LeftDown = self.line_intersection(self.DownLine, self.LeftLine)

                if self.DownLine is not None and self.RightLine is not None:
                    # Right down corner
                    RightDown = self.line_intersection(self.DownLine, self.RightLine)

                if self.UpLine is not None and self.RightLine is not None:
                    # Right up corner
                    RightUp = self.line_intersection(self.UpLine, self.RightLine)

                return LeftUp, LeftDown, RightDown, RightUp
            except NameError:
                self.Gamma_Min = self.Gamma_Min + 1
                if (self.Gamma_Min > 255): self.Gamma_Min = 0

            # try:
            #     if self.UpLine and self.LeftLine:
            #         # Left up corner
            #         LeftUp = self.line_intersection(self.UpLine[0], self.LeftLine[0])
            #     if self.DownLine and self.LeftLine:
            #         # Left down corner
            #         LeftDown = self.line_intersection(self.DownLine[0], self.LeftLine[0])
            #     if self.DownLine and self.RightLine:
            #         # Right down corner
            #         RightDown = self.line_intersection(self.DownLine[0], self.RightLine[0])
            #     if self.UpLine and self.RightLine:
            #         # Right up corner
            #         RightUp = self.line_intersection(self.UpLine[0], self.RightLine[0])
            #
            #     return LeftUp, LeftDown, RightDown, RightUp
            #
            # except NameError:
            #     self.Gamma_Min = self.Gamma_Min + 1
            #     if(self.Gamma_Min > 255) : self.Gamma_Min = 0

    def det(self, a, b):
        return a[0] * b[1] - a[1] * b[0]

    def line_intersection(self, line1, line2):

        x1, y1, x2, y2 = line1
        a1, b1, a2, b2 = line2
        
        xdiff = (x1 - x2, a1 - a2)
        ydiff = (y1 - y2, b1 - b2)

        div = self.det(xdiff, ydiff)
        if div == 0:
            raise Exception('lines do not intersect')

        d = (self.det((x1, y1), (x2, y2)), self.det((a1, b1), (a2, b2)))
        x = self.det(d, xdiff) / div
        y = self.det(d, ydiff) / div
        return int(x), int(y)

    def SlopeCalc(self, lines):
        Angle_Sum = np.array([(180 / np.pi) * np.arctan2(lines[:, :, 3] - lines[:, :, 1],
                                                         lines[:, :, 2] - lines[:, :, 0])])
        Angle_Sum = Angle_Sum.reshape(Angle_Sum.shape[1], Angle_Sum.shape[0], Angle_Sum.shape[2])
        slopeLines = np.append(lines, Angle_Sum, axis=2)
        return slopeLines

    def LinesFilter(self, slopeLines, threshold1, threshold2):
        # Net filter

        if threshold1 == NTL and threshold2 == NTR:
            slopeLines = slopeLines[slopeLines[..., 4] > 5]  # slope
        if slopeLines is not None:
            slopeLines = slopeLines[slopeLines[..., 0] > threshold1]  # x1
        if slopeLines is not None:
            slopeLines = slopeLines[slopeLines[..., 0] < threshold2]  # x1
        if slopeLines is not None:
            slopeLines = slopeLines[slopeLines[..., 2] > threshold1]  # x2
        if slopeLines is not None:
            slopeLines = slopeLines[slopeLines[..., 2] < threshold2]  # x2

        if len(slopeLines) >= 1:
            X1 = np.mean(slopeLines[..., 0])  # x1
            X2 = np.mean(slopeLines[..., 2])  # y1
            Y1 = np.mean(slopeLines[..., 1])  # x2
            Y2 = np.mean(slopeLines[..., 3])  # y2

            avgLine = int(X1), int(Y1), int(X2), int(Y2)
            return avgLine

    def draw_field(self, frame, Leftup, LeftDown, RightDown, RightUp):
        # Polygon corner points coordinates
        pts = np.array([Leftup, LeftDown, RightDown, RightUp])
        overlay = frame.copy()
       # cv2.drawContours(overlay, [pts], 0, (255, 0, 255), -1)
        cv2.addWeighted(overlay, 0.2, frame, 1, 0, frame)
        return frame